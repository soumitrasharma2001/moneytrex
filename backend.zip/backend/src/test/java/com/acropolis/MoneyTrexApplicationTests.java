package com.acropolis;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MoneyTrexApplicationTests {

	@Test
	void contextLoads() {
	}

}
